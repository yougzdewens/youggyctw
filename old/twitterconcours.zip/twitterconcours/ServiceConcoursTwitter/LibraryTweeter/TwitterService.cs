﻿using LibraryTweeter.Business;
using LibraryTweeter.Externals;
using LibraryTweeter.Model;
using LibraryTweeter.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using TweetSharp;

namespace LibraryTweeter
{
	/// <summary>
	/// 
	/// </summary>
	public class TwitterService
	{
		#region private field
		/// <summary>
		/// The message business
		/// </summary>
		private MessageBusiness messageBusiness = new MessageBusiness();

		/// <summary>
		/// The last identifier seen business
		/// </summary>
		private LastIdSeenBusiness lastIdSeenBusiness = new LastIdSeenBusiness();

		/// <summary>
		/// The citation business
		/// </summary>
		private CitationBusiness citationBusiness = new CitationBusiness();

		/// <summary>
		/// The retweet business
		/// </summary>
		private RetweetBusiness retweetBusiness = new RetweetBusiness();

		/// <summary>
		/// The syn bot manager
		/// </summary>
		private SynBotManager synBotManager = new SynBotManager();

		/// <summary>
		/// The friends business
		/// </summary>
		private FriendsBusiness friendsBusiness = new FriendsBusiness();

		/// <summary>
		/// The twitter manager
		/// </summary>
		private TwitterManager twitterManager = new TwitterManager();

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="TwitterService" /> class.
		/// </summary>
		public TwitterService()
		{
			twitterManager.DeleteDirectMessages();
			this.messageBusiness.DeleteAll();
		}

		/// <summary>
		/// Starts the search direct message.
		/// </summary>
		public void StartSearchDirectMessage()
		{
			while (true)
			{
				try
				{
					SearchDirectMessage();
					Thread.Sleep(new TimeSpan(0, 1, 0));
				}
				catch (Exception ex)
				{
					LogTool.WriteLog("erreur StartSearchDirectMessage");
					LogTool.WriteLog(ex.ToString());
					Thread.Sleep(new TimeSpan(0, 5, 0));
				}
			}
		}

		/// <summary>
		/// Starts the search citation.
		/// </summary>
		public void StartSearchCitation()
		{
			bool isFirstLaunch = false;

			while (true)
			{
				try
				{
					SearchCitation(isFirstLaunch);
					Thread.Sleep(new TimeSpan(0, 5, 0));
				}
				catch (Exception ex)
				{
					LogTool.WriteLog("erreur StartSearchCitation");
					LogTool.WriteLog(ex.ToString());
					Thread.Sleep(new TimeSpan(0, 5, 0));
				}

				isFirstLaunch = false;
			}
		}

		/// <summary>
		/// Starts the cycle.
		/// </summary>
		public void StartCycle()
		{
			while (true)
			{
				try
				{
					SearchConcoursFromOurContacts();
				}
				catch (Exception ex)
				{
					LogTool.WriteLog("erreur SearchConcoursFromOurContacts");
					LogTool.WriteLog(ex.ToString());
					Thread.Sleep(new TimeSpan(0, 5, 0));
				}

				retweetBusiness.Purge();
				synBotManager.SanitizeBot();
				Thread.Sleep(new TimeSpan(0, 5, 0));
			}
		}

		/// <summary>
		/// Deletes all data in database.
		/// </summary>
		public void DeleteAllDataInDB()
		{
			citationBusiness.DeleteALL();
			friendsBusiness.DeleteALL();
			lastIdSeenBusiness.DeleteALL();
			messageBusiness.DeleteAll();
			retweetBusiness.DeleteALL();
		}

		/// <summary>
		/// Searches the direct message.
		/// </summary>
		private void SearchDirectMessage()
		{
			long? lastId = messageBusiness.GetLastMessage();
			List<TwitterDirectMessage> tweets = twitterManager.GetDirectMessageReceived(lastId);

			tweets = tweets?.OrderBy(x => x.CreatedDate).ToList();

			foreach (TwitterDirectMessage tweet in tweets)
			{
				if (!messageBusiness.IsMessageExistWithIdMessageTwitter(tweet.Id))
				{
					string responseText = synBotManager.GetResponseFromBot(tweet.SenderId, tweet.Text);

					if (responseText != string.Empty)
					{
						bool isSent = twitterManager.SendDirectMessage(tweet.SenderId, responseText);

						if (isSent)
						{
							MessageModel message = new MessageModel();
							message.IdMessageTweeter = tweet.Id;
							message.Text = SqlTool.SanitizeForSql(tweet.Text);
							message.IdTwitterFriend = tweet.SenderId;
							message.Date = DateTime.Now;
							message.Response = SqlTool.SanitizeForSql(responseText);

							messageBusiness.Save(message);
						}
					}
				}
			}
		}

		/// <summary>
		/// Searches the citation.
		/// </summary>
		/// <param name="isFirstLaunch">if set to <c>true</c> [is first launch].</param>
		private void SearchCitation(bool isFirstLaunch = false)
		{
			List<TwitterStatus> tweets = twitterManager.GetTweetsMentionningMe();

			foreach (TwitterStatus tweet in tweets)
			{
				List<List<string>> listOfListWords = new List<List<string>>();
				listOfListWords.Add(new List<string>() { " dm", "remport" });
				listOfListWords.Add(new List<string>() { " mp", "remport" });
				listOfListWords.Add(new List<string>() { " mp", "gagn" });
				listOfListWords.Add(new List<string>() { "message", "priv", "gagn" });

				string contentToTest = tweet.FullText != null ? tweet.FullText : tweet.Text;

				if (!citationBusiness.IsCitationExist(tweet.Id))
				{
					if (!isFirstLaunch && StringTool.TestIfContainsWord(contentToTest, listOfListWords, true))
					{
						bool isSent = twitterManager.SendDirectMessage(tweets.First().User.Id, "Salut, visiblement j'ai peut être gagné, tu voulais me voir en MP ? :)");

						if (isSent)
						{
							synBotManager.SendMessageToTheChat(tweet.User.Id, contentToTest);
						}
					}

					citationBusiness.Save(tweet);
				}
			}
		}

		/// <summary>
		/// Searches the concours from our contacts.
		/// </summary>
		private void SearchConcoursFromOurContacts()
		{
			List<FriendsModel> allFriends = friendsBusiness.GetAll();

			foreach (FriendsModel friend in allFriends)
			{
				List<TwitterStatus> tweetsFromFriend = twitterManager.GetTweetFromFriend(friend.IdTwitterFriend, lastIdSeenBusiness.Get(friend.IdTwitterFriend));
						
				if (tweetsFromFriend != null && tweetsFromFriend.Count > 0)
				{
					LogTool.WriteLog(string.Format("{0} Tweets trouvé pour {1}", tweetsFromFriend.Count, friend.IdTwitterFriend));

					LastIdSeenModel lastIdSeenModel = new LastIdSeenModel();
					lastIdSeenModel.IdOfLastTweetSeen = tweetsFromFriend[0].Id;
					lastIdSeenModel.IdTwitterFriend = friend.IdTwitterFriend;

					lastIdSeenBusiness.AddOrUpdate(lastIdSeenModel);

					string searchAndFollow = System.Configuration.ConfigurationManager.AppSettings["searchAndFollow"];
					List<List<string>> listWordsToFindRTFollow = searchAndFollow.Split(';').Select(x => x.Split(',').ToList()).ToList();

					foreach (TwitterStatus twitterStatus in tweetsFromFriend)
					{
						string contentToTest = twitterStatus.FullText != null ? twitterStatus.FullText : twitterStatus.Text;

						if (StringTool.TestIfContainsWord(contentToTest, listWordsToFindRTFollow, true))
						{
							if (!retweetBusiness.IsExist(twitterStatus.Id))
							{
								bool retweetOk = twitterManager.RetweetATweet(twitterStatus);

								LogTool.WriteLog(string.Format("Tweet n°{0} de {1} retweeté", twitterStatus.Id, twitterStatus.User.ScreenName));

								if (StringTool.TestIfContainsWord(contentToTest, new List<string>() { "like", "aime" }))
								{
									twitterManager.LikeATweet(twitterStatus);
									LogTool.WriteLog(string.Format("Tweet n°{0} de {1} liké", twitterStatus.Id, twitterStatus.User.ScreenName));
								}								

								RetweetModel retweetModel = new RetweetModel();
								retweetModel.IdTweet = twitterStatus.Id;
								retweetModel.IdTwitterFriend = friend.IdTwitterFriend;
								retweetModel.DateInserted = DateTime.Now;

								retweetBusiness.Save(retweetModel);
							}
						}
					}
				}
			}
		}
	}
}