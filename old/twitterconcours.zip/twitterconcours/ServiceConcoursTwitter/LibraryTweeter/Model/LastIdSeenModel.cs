﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryTweeter.Model
{
	public class LastIdSeenModel
	{
		public long IdOfLastTweetSeen { get; set; }

		public long IdTwitterFriend { get; set; }
	}
}
