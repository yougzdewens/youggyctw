﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestTweeter
{
    class Program
    {
        static void Main(string[] args)
        {
			LibraryTweeter.TwitterService twitterService = new LibraryTweeter.TwitterService();

			//Task task0 = Task.Factory.StartNew(() => { twitterService.DeleteAllDataInDB(); });

			Task task1 = Task.Factory.StartNew(() => { twitterService.StartCycle(); });
            Task task2 = Task.Factory.StartNew(() => { twitterService.StartSearchCitation(); });
            Task task3 = Task.Factory.StartNew(() => { twitterService.StartSearchDirectMessage(); });

            Console.ReadLine();
        }
    }
}