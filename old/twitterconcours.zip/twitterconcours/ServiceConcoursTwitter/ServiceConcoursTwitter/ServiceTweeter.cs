﻿using System.ServiceProcess;
using System.Threading.Tasks;

namespace ServiceConcoursTwitter
{
	/// <summary>
	/// 
	/// </summary>
	/// <seealso cref="System.ServiceProcess.ServiceBase" />
	public partial class ServiceTweeter : ServiceBase
    {
		/// <summary>
		/// Initializes a new instance of the <see cref="ServiceTweeter"/> class.
		/// </summary>
		public ServiceTweeter()
        {
            InitializeComponent();

			//Debugger.Launch();

			LibraryTweeter.TwitterService twitterService = new LibraryTweeter.TwitterService();

			Task task1 = Task.Factory.StartNew(() => { twitterService.StartCycle(); });
			Task task2 = Task.Factory.StartNew(() => { twitterService.StartSearchCitation(); });
			Task task3 = Task.Factory.StartNew(() => { twitterService.StartSearchDirectMessage(); });
		}

		/// <summary>
		/// Si elle est implémentée dans une classe dérivée, cette méthode s'exécute lorsqu'une commande Démarrer est envoyée au service par le Gestionnaire de contrôle des services (SCM) ou lorsque le système d'exploitation démarre (pour un service qui démarre automatiquement). Spécifie les actions à effectuer lorsque le service démarre.
		/// </summary>
		/// <param name="args">Données passées par la commande de démarrage.</param>
		protected override void OnStart(string[] args)
        {
            
        }

		/// <summary>
		/// Si elle est implémentée dans une classe dérivée, cette méthode s'exécute lorsqu'une commande Arrêter est envoyée au service par le Gestionnaire de contrôle des services (SCM). Spécifie les actions à effectuer lorsqu'un service cesse de s'exécuter.
		/// </summary>
		protected override void OnStop()
        {
        }
    }
}
